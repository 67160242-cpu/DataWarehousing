"""
Load stage of the ETL pipeline.

Loads the transformed data into a SQLite warehouse with three tables:
dim_customer, dim_product, fact_sales.

Idempotency: `order_id` is declared UNIQUE on fact_sales, and each run
does a full refresh (DELETE + INSERT) of all three tables inside a
single transaction. Running the pipeline N times therefore always
leaves the warehouse with exactly the same row counts as one run.
"""
import logging
import sqlite3
from pathlib import Path

import pandas as pd

logger = logging.getLogger("etl.load")

BASE_DIR = Path(__file__).resolve().parent.parent
WAREHOUSE_PATH = BASE_DIR / "data" / "warehouse" / "warehouse.db"

DDL = """
CREATE TABLE IF NOT EXISTS dim_customer (
    customer_id TEXT PRIMARY KEY,
    name        TEXT,
    province    TEXT,
    email       TEXT
);

CREATE TABLE IF NOT EXISTS dim_product (
    product_id   TEXT PRIMARY KEY,
    product_name TEXT,
    category     TEXT,
    price        REAL
);

CREATE TABLE IF NOT EXISTS fact_sales (
    order_id      TEXT UNIQUE,
    customer_id   TEXT,
    product_id    TEXT,
    order_date    TEXT,
    qty           INTEGER,
    unit_price    REAL,
    discount_pct  REAL,
    sales_amount  REAL
);
"""


def get_connection(path: Path = WAREHOUSE_PATH) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.executescript(DDL)
    return con


def load_all(transformed: dict, path: Path = WAREHOUSE_PATH) -> None:
    con = get_connection(path)
    try:
        cur = con.cursor()

        # Full refresh keeps every load idempotent: same input -> same
        # warehouse state, no matter how many times the pipeline runs.
        cur.execute("DELETE FROM fact_sales")
        cur.execute("DELETE FROM dim_customer")
        cur.execute("DELETE FROM dim_product")

        dim_customer = transformed["customers"][["customer_id", "name", "province", "email"]]
        dim_product = transformed["products"][["product_id", "product_name", "category", "price"]]
        fact_sales = transformed["sales"][
            ["order_id", "customer_id", "product_id", "order_date", "qty", "unit_price", "discount_pct", "sales_amount"]
        ]

        dim_customer.to_sql("dim_customer", con, if_exists="append", index=False)
        dim_product.to_sql("dim_product", con, if_exists="append", index=False)
        fact_sales.to_sql("fact_sales", con, if_exists="append", index=False)

        con.commit()
        logger.info(
            "loaded dim_customer=%d dim_product=%d fact_sales=%d rows into %s",
            len(dim_customer), len(dim_product), len(fact_sales), path,
        )
    finally:
        con.close()


def read_fact_sales_count(path: Path = WAREHOUSE_PATH) -> int:
    con = sqlite3.connect(path)
    try:
        cur = con.execute("SELECT COUNT(*) FROM fact_sales")
        return cur.fetchone()[0]
    finally:
        con.close()
