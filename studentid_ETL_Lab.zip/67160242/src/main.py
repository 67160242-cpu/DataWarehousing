"""
Entry point: python -m src.main

Runs Extract -> Transform -> Load -> Validate, writes
output/rejects.csv, output/validation.json and logs/etl.log.
"""
import logging
from pathlib import Path

from src.extract import extract_all
from src.transform import transform_all
from src.load import load_all
from src.validate import validate

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_PATH = BASE_DIR / "logs" / "etl.log"
REJECTS_PATH = BASE_DIR / "output" / "rejects.csv"


def configure_logging():
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(LOG_PATH, mode="a", encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def run():
    configure_logging()
    logger = logging.getLogger("etl.main")
    logger.info("=== ETL pipeline run started ===")

    logger.info("--- Extract ---")
    raw = extract_all()

    logger.info("--- Transform ---")
    transformed = transform_all(raw)

    REJECTS_PATH.parent.mkdir(parents=True, exist_ok=True)
    transformed["rejects"].to_csv(REJECTS_PATH, index=False)
    logger.info("wrote %d rejected rows to %s", len(transformed["rejects"]), REJECTS_PATH)

    logger.info("--- Load ---")
    load_all(transformed)

    logger.info("--- Validate ---")
    result = validate(transformed)
    logger.info("=== ETL pipeline run finished: %s ===", result["status"])
    return result


if __name__ == "__main__":
    run()
