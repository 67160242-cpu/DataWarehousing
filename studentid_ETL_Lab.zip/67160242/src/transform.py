"""
Transform stage of the ETL pipeline.

Cleans customers / products / orders, merges them into a sales fact
table, and separates out any record that fails a validation rule
into a `rejects` dataframe (nothing is silently dropped).
"""
import logging
import re

import numpy as np
import pandas as pd

logger = logging.getLogger("etl.transform")

VALID_STATUSES = {"paid", "completed"}

# Canonical province lookup. Keys are pre-normalized (stripped, lower-cased,
# with internal whitespace removed) so lots of dirty spellings map to one
# clean value.
PROVINCE_MAP = {
    "bkk": "Bangkok",
    "bangkok": "Bangkok",
    "กรุงเทพฯ": "Bangkok",
    "กรุงเทพ": "Bangkok",
    "chonburi": "Chonburi",
    "chonbuti": "Chonburi",
    "chonburi.": "Chonburi",
    "chon buri": "Chonburi",
    "ชลบุรี": "Chonburi",
    "rayong": "Rayong",
    "ระยอง": "Rayong",
    "chanthaburi": "Chanthaburi",
    "chantaburi": "Chanthaburi",  # common misspelling in the source
    "จันทบุรี": "Chanthaburi",
}


def _normalize_key(value: str) -> str:
    return re.sub(r"\s+", " ", str(value).strip().lower())


def standardize_province(value) -> str:
    if pd.isna(value) or str(value).strip() == "":
        return "Unknown"
    key = _normalize_key(value)
    key_nospace = key.replace(" ", "")
    return PROVINCE_MAP.get(key, PROVINCE_MAP.get(key_nospace, value.strip().title()))


# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------
def clean_customers(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    before = len(df)
    df = df.drop_duplicates(subset="customer_id", keep="first")
    logger.info("customers: removed %d duplicate customer_id rows", before - len(df))

    df["province"] = df["province"].apply(standardize_province)
    df["email"] = df["email"].where(df["email"].notna() & (df["email"].str.strip() != ""), "unknown@example.com")
    df["name"] = df["name"].fillna("Unknown")

    logger.info("customers: cleaned shape=%s", df.shape)
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------
def _clean_price(value) -> float:
    if pd.isna(value):
        return np.nan
    if isinstance(value, (int, float)):
        return float(value)
    # strings like "1,299.00"
    cleaned = str(value).replace(",", "").strip()
    try:
        return float(cleaned)
    except ValueError:
        return np.nan


def clean_products(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.rename(columns={"category.name": "category", "pricing.price": "price"})
    df["price"] = df["price"].apply(_clean_price)
    df["category"] = df["category"].where(df["category"].notna() & (df["category"].astype(str).str.strip() != ""), "Unknown")
    df = df[["product_id", "product_name", "category", "price"]]
    logger.info("products: cleaned shape=%s", df.shape)
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------
DATE_FORMATS = ["%Y/%m/%d", "%d/%m/%Y", "%d-%b-%Y", "%Y-%m-%d"]


def _parse_date(value):
    if pd.isna(value):
        return pd.NaT
    text = str(value).strip()
    for fmt in DATE_FORMATS:
        try:
            return pd.to_datetime(text, format=fmt)
        except ValueError:
            continue
    return pd.NaT


def _to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def clean_orders(df: pd.DataFrame):
    """
    Returns (clean_orders_df, rejects_df) where clean_orders_df has passed
    every row-level validation rule and rejects_df lists every row that
    failed, with a reason.
    """
    df = df.copy()
    rejects = []

    # --- duplicate order_id -------------------------------------------------
    dup_mask = df.duplicated(subset="order_id", keep="first")
    n_duplicates = int(dup_mask.sum())
    if n_duplicates:
        dup_rows = df[dup_mask].copy()
        dup_rows["reject_reason"] = "duplicate_order_id"
        rejects.append(dup_rows)
    df = df[~dup_mask].copy()
    logger.info("orders: found %d duplicate order_id rows (dropped, kept first occurrence)", n_duplicates)

    # --- type coercion -------------------------------------------------------
    df["qty_num"] = _to_numeric(df["qty"])
    df["unit_price_num"] = _to_numeric(df["unit_price"])
    df["discount_pct_num"] = _to_numeric(df["discount_pct"])
    df["order_date_parsed"] = df["order_date"].apply(_parse_date)
    df["status"] = df["status"].astype(str).str.strip().str.lower()

    # --- row-level validation rules ------------------------------------------
    reasons = pd.Series([""] * len(df), index=df.index)

    bad_qty = df["qty_num"].isna() | (df["qty_num"] <= 0)
    reasons = reasons.mask(bad_qty & (reasons == ""), "invalid_qty")

    bad_price = df["unit_price_num"].isna() | (df["unit_price_num"] <= 0)
    reasons = reasons.mask(bad_price & (reasons == ""), "invalid_unit_price")

    bad_discount = df["discount_pct_num"].isna() | (df["discount_pct_num"] < 0) | (df["discount_pct_num"] > 100)
    reasons = reasons.mask(bad_discount & (reasons == ""), "invalid_discount_pct")

    bad_date = df["order_date_parsed"].isna()
    reasons = reasons.mask(bad_date & (reasons == ""), "invalid_date")

    original_cols = ["order_id", "customer_id", "product_id", "order_date", "qty", "unit_price", "discount_pct", "status"]

    is_bad = reasons != ""
    if is_bad.any():
        bad_rows = df[is_bad].copy()
        bad_rows["reject_reason"] = reasons[is_bad]
        rejects.append(bad_rows[original_cols + ["reject_reason"]])

    clean = df[~is_bad].copy()
    clean["qty"] = clean["qty_num"].astype(int)
    clean["unit_price"] = clean["unit_price_num"].astype(float)
    clean["discount_pct"] = clean["discount_pct_num"].astype(float)
    clean["order_date"] = clean["order_date_parsed"].dt.strftime("%Y-%m-%d")
    clean = clean[["order_id", "customer_id", "product_id", "order_date", "qty", "unit_price", "discount_pct", "status"]]

    rejects_df = pd.concat(rejects, ignore_index=True) if rejects else pd.DataFrame(
        columns=list(df.columns) + ["reject_reason"]
    )

    logger.info("orders: %d rows passed row-level validation, %d rejected", len(clean), len(rejects_df))
    return clean.reset_index(drop=True), rejects_df, n_duplicates


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------
def merge_sales(clean_orders: pd.DataFrame, customers: pd.DataFrame, products: pd.DataFrame):
    """
    Keep only paid/completed orders, join with customer & product master
    data, and compute the sales amounts. Orders whose customer_id or
    product_id is missing from the master data are routed to rejects.
    """
    df = clean_orders[clean_orders["status"].isin(VALID_STATUSES)].copy()

    known_customers = set(customers["customer_id"])
    known_products = set(products["product_id"])

    missing_customer = ~df["customer_id"].isin(known_customers)
    missing_product = ~df["product_id"].isin(known_products)
    missing_master = missing_customer | missing_product

    reject_rows = []
    if missing_master.any():
        bad = df[missing_master].copy()
        reason = np.where(
            missing_customer[missing_master] & missing_product[missing_master],
            "customer_and_product_not_found",
            np.where(missing_customer[missing_master], "customer_not_found", "product_not_found"),
        )
        bad["reject_reason"] = reason
        reject_rows.append(bad)

    df = df[~missing_master].copy()

    merged = df.merge(customers, on="customer_id", how="left").merge(
        products, on="product_id", how="left", suffixes=("", "_product")
    )

    merged["gross_amount"] = merged["qty"] * merged["unit_price"]
    merged["discount_amount"] = merged["gross_amount"] * merged["discount_pct"] / 100
    merged["sales_amount"] = merged["gross_amount"] - merged["discount_amount"]

    merge_rejects = pd.concat(reject_rows, ignore_index=True) if reject_rows else pd.DataFrame(
        columns=list(df.columns) + ["reject_reason"]
    )

    logger.info("merge: %d sales rows built, %d rows rejected for missing master data", len(merged), len(merge_rejects))
    return merged.reset_index(drop=True), merge_rejects


def transform_all(raw: dict) -> dict:
    customers = clean_customers(raw["customers"])
    products = clean_products(raw["products"])
    clean_orders_df, order_rejects, n_duplicates = clean_orders(raw["orders"])
    sales, merge_rejects = merge_sales(clean_orders_df, customers, products)

    all_rejects = pd.concat([order_rejects, merge_rejects], ignore_index=True, sort=False)

    result = {
        "customers": customers,
        "products": products,
        "clean_orders": clean_orders_df,
        "sales": sales,
        "rejects": all_rejects,
        "duplicate_order_ids": n_duplicates,
    }
    return result


if __name__ == "__main__":
    import logging as _logging
    from src.extract import extract_all

    _logging.basicConfig(level=_logging.INFO)
    raw = extract_all()
    out = transform_all(raw)
    print("sales shape:", out["sales"].shape)
    print("rejects shape:", out["rejects"].shape)
    print("total sales:", out["sales"]["sales_amount"].sum())
