"""
Validate stage of the ETL pipeline.

Cross-checks the transformed (source) data against what actually
landed in the warehouse, and writes output/validation.json.
"""
import json
import logging
import sqlite3
from pathlib import Path

import pandas as pd

logger = logging.getLogger("etl.validate")

BASE_DIR = Path(__file__).resolve().parent.parent
WAREHOUSE_PATH = BASE_DIR / "data" / "warehouse" / "warehouse.db"
VALIDATION_PATH = BASE_DIR / "output" / "validation.json"


def validate(transformed: dict, warehouse_path: Path = WAREHOUSE_PATH) -> dict:
    sales = transformed["sales"]
    source_valid_rows = len(sales)
    source_total_sales = round(float(sales["sales_amount"].sum()), 2)
    duplicate_order_ids = int(transformed["duplicate_order_ids"])

    con = sqlite3.connect(warehouse_path)
    try:
        warehouse_rows = pd.read_sql_query("SELECT COUNT(*) AS n FROM fact_sales", con)["n"].iloc[0]
        warehouse_total_sales = pd.read_sql_query(
            "SELECT COALESCE(SUM(sales_amount), 0) AS total FROM fact_sales", con
        )["total"].iloc[0]
    finally:
        con.close()

    warehouse_rows = int(warehouse_rows)
    warehouse_total_sales = round(float(warehouse_total_sales), 2)

    status = "PASS" if (
        source_valid_rows == warehouse_rows
        and abs(source_total_sales - warehouse_total_sales) < 0.01
    ) else "FAIL"

    result = {
        "source_valid_rows": source_valid_rows,
        "warehouse_rows": warehouse_rows,
        "duplicate_order_ids": duplicate_order_ids,
        "source_total_sales": source_total_sales,
        "warehouse_total_sales": warehouse_total_sales,
        "status": status,
    }

    VALIDATION_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(VALIDATION_PATH, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    logger.info("validation result: %s", result)
    return result
