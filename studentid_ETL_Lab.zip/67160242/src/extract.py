"""
Extract stage of the ETL pipeline.

Reads all raw data sources and returns them as a dict of pandas
DataFrames, keyed the way the assignment expects:

    raw = {
        "customers": ...,
        "orders": ...,
        "products": ...,
        "stores": ...,
    }
"""
import json
import logging
import sqlite3
from pathlib import Path

import pandas as pd

logger = logging.getLogger("etl.extract")

BASE_DIR = Path(__file__).resolve().parent.parent
CUSTOMERS_PATH = BASE_DIR / "customers.csv"
ORDERS_PATH = BASE_DIR / "orders.csv"
PRODUCTS_PATH = BASE_DIR / "products.json"
STORE_DB_PATH = BASE_DIR / "store.db"


def extract_customers(path: Path = CUSTOMERS_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str)
    logger.info("Extracted customers.csv shape=%s columns=%s", df.shape, list(df.columns))
    return df


def extract_orders(path: Path = ORDERS_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str)
    logger.info("Extracted orders.csv shape=%s columns=%s", df.shape, list(df.columns))
    return df


def extract_products(path: Path = PRODUCTS_PATH) -> pd.DataFrame:
    with open(path, "r", encoding="utf-8") as f:
        raw_json = json.load(f)
    # Flatten nested JSON (category.name, pricing.price, ...)
    df = pd.json_normalize(raw_json)
    logger.info("Extracted products.json shape=%s columns=%s", df.shape, list(df.columns))
    return df


def extract_stores(path: Path = STORE_DB_PATH) -> pd.DataFrame:
    con = sqlite3.connect(path)
    try:
        df = pd.read_sql_query("SELECT * FROM stores", con)
    finally:
        con.close()
    logger.info("Extracted stores table shape=%s columns=%s", df.shape, list(df.columns))
    return df


def extract_all() -> dict:
    """Run the full extract step and return the raw dataframes."""
    raw = {
        "customers": extract_customers(),
        "orders": extract_orders(),
        "products": extract_products(),
        "stores": extract_stores(),
    }

    # Checkpoint: shapes / columns before moving into Transform
    for name, df in raw.items():
        logger.info("[checkpoint] %s -> shape=%s, columns=%s", name, df.shape, list(df.columns))

    return raw


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    data = extract_all()
    for k, v in data.items():
        print(f"\n=== {k} ===")
        print(v.head())
        print(v.shape)
