Student ID: 67160242
Name: อรรณพ ศรีผ่อง

## 1. Data Quality Problems Found
- **customers.csv**: มี `customer_id` ซ้ำ ได้เเเก่ C004, C009 พบ 2 ครั้ง, `province` พบการเขียนหลายแบบ เช่น ( BKK, bangkok, กรุงเทพฯ, chon buri, ชลบุรี, CHONBURI, rayong, RAYONG, ระยอง, Chanthaburi, CHANTHABURI, จันทบุรี, chantaburi  ) และมี `province`/`email` มีค่าว่างในบางแถว ตัวอย่าง C013 ไม่มี province, C006 ไม่มี email
- **products.json**: โครงสร้างเป็น nested JSON (`category.name`, `pricing.price`) ต้อง flatten ก่อนใช้งาน, บาง record ไม่มี category (`null`), และ`pricing.price` บางค่าเป็น string ที่มี "," คั่นหลักพัน ตัวอย่าง "1,299.00" แทนที่จะเป็นตัวเลข
- **orders.csv**: มี `order_id` ซ้ำ 3 รายการ ได้เเก่ O0011, O0041, O0101, รูปแบบวันที่ปนกัน 4 แบบ (`YYYY/MM/DD`, `DD/MM/YYYY`, `DD-Mon-YYYY`, `YYYY-MM-DD`) รวมถึงค่าที่ parse ไม่ได้เลย (`not-a-date`), `status` เขียนตัวพิมพ์เล็กเเละใหญ่ปนกัน (PAID, paid), และค่าที่ผิดกฎธุรกิจ ได้แก่ `qty` ติดลบ, `unit_price` ติดลบ, `discount_pct` เกิน 100

## 2. Cleaning / Transformation Rules
- **Customers**: ลบ duplicate ด้วย `drop_duplicates(subset="customer_id", keep="first")`; map ค่าจังหวัดที่เขียนต่างกันไปเป็นมาตรฐานเดียว (Bangkok / Chonburi / Rayong / Chanthaburi) ผ่าน lookup table ที่ normalize ตัวพิมพ์เล็ก-ใหญ่และช่องว่างก่อนเทียบ; ค่า province ว่าง → `"Unknown"`, ค่า email ว่าง → `"unknown@example.com"`
- **Products**: ใช้ `pd.json_normalize()` แปลง JSON ให้แบน แล้วเปลี่ยนชื่อคอลัมน์ `category.name` → `category`, `pricing.price` → `price`; แปลง price เป็น numeric โดยลบ comma ออกก่อนแปลง (`str.replace(",", "")` แล้ว `float()`); category ที่ขาดหาย → `"Unknown"`
- **Orders**: ลบ duplicate order_id (`keep="first"`, ที่เหลือย้ายไป rejects); parse วันที่ด้วยการลองทีละ format ทั้ง 4 แบบจนกว่าจะสำเร็จ; แปลง `status` เป็นตัวพิมพ์เล็กทั้งหมด (`str.lower()`); ปฏิเสธ (reject) แถวที่ `qty <= 0`, `unit_price <= 0`, `discount_pct < 0` หรือ `> 100`, หรือ parse วันที่ไม่สำเร็จ
- **Merge**: กรองเฉพาะ order ที่ `status` เป็น `paid` หรือ `completed` แล้ว join กับ dim customers/products; order ที่ `customer_id`/`product_id` ไม่พบใน master data จะถูกย้ายไป rejects แทนที่จะ join แบบเงียบ ๆ; คำนวณ `gross_amount = qty * unit_price`, `discount_amount = gross_amount * discount_pct / 100`, `sales_amount = gross_amount - discount_amount`

## 3. Rejected Records
จำนวน: 7 รายการ 
เหตุผล:
- `duplicate_order_id` — พบ 3 รายการ ได้เเก่ O0่011, O0041, O0101
- `invalid_qty` — มี 1 รายการ ที่ qty ติดลบ
- `invalid_unit_price` — มี 1 รายการ ที่ unit_price ติดลบ
- `invalid_discount_pct` — มี 1 รายการ ที่ discount_pct = 150 เเต่เกิน 100
- `invalid_date` — มี 1 รายการ `order_date` = "not-a-date"

## 4. ETL Validation
- Valid transformed rows: 100
- Warehouse rows: 100
- Duplicate order_id: 3
- Source total sales: 192,074.66
- Warehouse total sales: 192,074.66
- Validation status: **PASS**

## 5. Idempotency Test
จำนวน fact_sales หลัง run ครั้งที่ 1: 100
จำนวน fact_sales หลัง run ครั้งที่ 2: 100
เหตุผล: เนื่องจากจำนวนแถวเท่าเดิมทุกครั้งที่ run เพราะขั้นตอน Load ใช้ full-refresh pattern — ก่อน insert จะ `DELETE` ข้อมูลเดิมทั้งหมดในตาราง `fact_sales`, `dim_customer`, `dim_product` ก่อนเสมอ แล้วจึง insert ข้อมูลที่ transform ใหม่ทั้งหมดเข้าไป นอกจากนี้ `order_id` ยังถูกกำหนดเป็น `UNIQUE` ใน schema เพื่อป้องกันไม่ให้เกิด record ซ้ำโดยไม่ได้ตั้งใจ ผลคือรัน pipeline กี่ครั้งด้วย input เดิม ก็จะได้ warehouse ที่มีสถานะเหมือนเดิมทุกครั้ง 
